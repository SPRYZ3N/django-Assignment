from django.shortcuts import render,HttpResponse,redirect
from .models import Book
from .forms import BookForm

# Create your views here.
def home(request):
    books=Book.objects.all();
    return render(request,'index.html',{'books_list':books})
    
def upload(request):
    #GET localhost:8000/upload
    upload=BookForm() #empty BookForm displayed , new instance 
    
    #POST - now BookForm filled fields and submitted
    if request.method=='POST':
        upload=BookForm(request.POST,request.FILES)
        
        if upload.is_valid():
            upload.save()
            return redirect('home')
        else:
            return HttpResponse("<h2>Error: You have not filled correct information</h2>")
    
    else:
        return render(request,'upload.html',{'upload_form':upload})
        

def update_book(request,book_id):
    
    book_id=int(book_id)
    
    try:
        book_select=Book.objects.get(id=book_id)
    except Book.DoesNotExist:
        return redirect('home')
    
    book_form=BookForm(request.POST or None,instance=book_select)
    if book_form.is_valid():
        book_form.save()
        return redirect('home')
    else:
        return render(request,'upload.html',{'upload_form':book_form})
    

def delete_book(request,book_id):
    book_id=int(book_id)
    
    try:
        book_select=Book.objects.get(id=book_id)
    except Book.DoesNotExist:
        return redirect('home')

    book_select.delete()
    return redirect('home')


        
