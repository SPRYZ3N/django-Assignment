from django import forms

class HelpForm(forms.Form):
    name = forms.CharField(label="Enter name", max_length=100)

    emp_id = forms.CharField(label="Enter id", max_length=10)
    description = forms.CharField(label="Describe the issue", max_length=100)


class EnquiryForm(forms.Form):
    name = forms.CharField(label="Enter name", max_length=100)
    email_id = forms.CharField(label="Enter email", max_length=100)