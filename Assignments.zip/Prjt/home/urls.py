from django.urls import include, path
from home import views

urlpatterns = [
    path('', views.index, name='home_page'),
    path('about', views.about, name='about'),
    path('help', views.help, name='forHelp')

]