from django.shortcuts import render, HttpResponse
from home.forms import HelpForm,EnquiryForm

# Create your views here.
def index(request):
    details = {
        'Title' : 'First WEB Page',
        'Status' : 'GET',
        'Company' : 'TTL',
        'Name' : 'Shabarish'
    }
    #return HttpResponse("This is Home page");
    return render(request,'index.html',details)

def about(request):
    obj=EnquiryForm();
    return render(request,'about.html',{'form':obj})

def help(request):
    obj=HelpForm();
    return render(request,'help.html',{'form':obj})


