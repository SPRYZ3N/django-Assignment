from django.shortcuts import render,get_object_or_404
from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Student
from .serializers import StudentSerializer

# Create your views here.
class StudentList(APIView):
    
    def get(self, request):
        students=Student.objects.all()
        ser=StudentSerializer(students,many=True)
        return Response(ser.data)  ## return JSON
        
    def post(self):
        pass