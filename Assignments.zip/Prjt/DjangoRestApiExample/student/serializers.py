"""from django import forms

class StudentForm(forms.ModelForm)"""

from rest_framework import serializers
from .models import Student 

#create a class
class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model=Student
        fields='__all__'
