from django import forms
#loading Student class from student app models.py
from student.models import Student


class StudentForm(forms.ModelForm):
    class Meta:
        model=Student
        fields="__all__"