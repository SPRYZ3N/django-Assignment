from django.shortcuts import render
from student.forms import StudentForm



# Create your views here.
def index(request):
    object=StudentForm()
    return render(request,'StudentForms.html',{'form':object})
