from django.db import models

# Create your models here.
class Student(models.Model):
    roll_no = models.CharField(max_length=40)
    name = models.CharField(max_length= 40)
    course = models.CharField(max_length=30)
    department = models.CharField(max_length=30)

    class Meta:
        model='student'
        field='__all__'




