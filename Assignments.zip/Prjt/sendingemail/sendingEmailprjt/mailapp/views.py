from django.shortcuts import render
from django.core.mail import send_mail,EmailMultiAlternatives
from django.conf import settings



# Create your views here.
def home(request):
    if request.method=='POST':
        #fetched form data
       sub=request.POST.get('subject')
       msg=request.POST.get('body')
       # Example 1
       # send_mail(subject, message, from_email, recipient_list)
       message=send_mail(sub,msg , settings.EMAIL_HOST_USER,['shabarishmenon95@gmail.com',])

       #example 2
       #msg = EmailMultiAlternatives(sub, msg,settings.EMAIL_HOST_USER ,['lohitha054@gmail.com','ssanthosha089@gmail.com','anshikakale0@gmail.com','ruchitalawand@gmail.com','shabarish664@gmail.com'])
       #msg.attach('ruby.jpg','/images')
       msg.send()

    return render(request,'mail.html')